## Drop all items in `multipack:graves`. 
## Requires that $(id), $(count), $(components), and $(Slot) correspond to the last item in `multipack:graves`.
$execute store result score &bool mp.temp as @p[tag=multipack.interactor] if score #graves.auto_equip mp.settings matches 1 unless items entity @s $(Slot) *
$execute if score &bool mp.temp matches 0 run summon item ~ ~ ~ {Item:{id:"$(id)",count:$(count),components:$(components)}}
$execute if score &bool mp.temp matches 1 run data modify entity @n[type=armor_stand,tag=multipack.grave,distance=..0.1] equipment.body set value {id:"$(id)",count:$(count),components:$(components)}
$execute if score &bool mp.temp matches 1 run item replace entity @p[tag=multipack.interactor] $(Slot) from entity @n[type=armor_stand,tag=multipack.grave,distance=..0.1] armor.body

data remove storage multipack:graves Items[-1]
execute unless data storage multipack:graves Items[-1].components run data modify storage multipack:graves Items[-1].components set value "{}"
function m_graves:graves/drop_items with storage multipack:graves Items[-1]
