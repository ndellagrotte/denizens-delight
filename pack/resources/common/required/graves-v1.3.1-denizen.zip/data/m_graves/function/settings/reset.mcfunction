data merge storage multipack:settings {graves:{toggle:1, despawn:0, despawn_minutes:10, despawn_hours:0, void_recovery:1, void_recovery_dist:100, \
  locked:0, key:0, auto_unlock:0, unlock_minutes:5, unlock_hours:0, death_coords:1, compass:1, auto_equip:1, \
  glowing:1, display_name:1, display_head:1, grave_decorators:1, keep_xp:0, keep_hotbar:0, keep_armor:0, keep_items:1, lose_items:0}}
function m_graves:settings/save_macro with storage multipack:settings graves
