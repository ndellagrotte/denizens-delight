clear
item replace entity @s hotbar.0 with minecraft:iron_pickaxe
item replace entity @s hotbar.1 with minecraft:rotten_flesh
item replace entity @s hotbar.2 with minecraft:diamond
item replace entity @s hotbar.3 with minecraft:netherite_upgrade_smithing_template
item replace entity @s hotbar.4 with minecraft:dragon_egg
item replace entity @s hotbar.5 with minecraft:oak_log
item replace entity @s hotbar.6 with minecraft:iron_chestplate
item replace entity @s inventory.0 with dirt
item replace entity @s armor.feet with minecraft:diamond_boots
item replace entity @s armor.legs with minecraft:diamond_leggings
item replace entity @s armor.chest with minecraft:diamond_chestplate
item replace entity @s armor.head with minecraft:diamond_helmet
item replace entity @s weapon.offhand with torch