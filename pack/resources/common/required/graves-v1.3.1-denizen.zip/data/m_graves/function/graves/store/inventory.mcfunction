## Clear and store this player's inventory and xp
clear @s *[enchantments~[{"enchantments":"vanishing_curse"}]]
execute if score #graves.lose_items mp.settings matches 1 run clear @s #m_graves:lost_items

# Store inventory data
data modify storage multipack:graves Items set from entity @s Inventory
data modify storage multipack:graves Items append from entity @s equipment.offhand
execute if items entity @s weapon.offhand * run data modify storage multipack:graves Items[-1].Slot set value "weapon.offhand"
data modify storage multipack:graves Items append from entity @s equipment.feet
execute if items entity @s armor.feet * run data modify storage multipack:graves Items[-1].Slot set value "armor.feet"
data modify storage multipack:graves Items append from entity @s equipment.legs
execute if items entity @s armor.legs * run data modify storage multipack:graves Items[-1].Slot set value "armor.legs"
data modify storage multipack:graves Items append from entity @s equipment.chest
execute if items entity @s armor.chest * run data modify storage multipack:graves Items[-1].Slot set value "armor.chest"
data modify storage multipack:graves Items append from entity @s equipment.head
execute if items entity @s armor.head * run data modify storage multipack:graves Items[-1].Slot set value "armor.head"

# Process items
execute if score #graves.keep_hotbar mp.settings matches 0 run function m_graves:graves/store/slot {slot:"hotbar.0",path:"Items[{Slot:0b}]"}
execute if score #graves.keep_hotbar mp.settings matches 0 run function m_graves:graves/store/slot {slot:"hotbar.1",path:"Items[{Slot:1b}]"}
execute if score #graves.keep_hotbar mp.settings matches 0 run function m_graves:graves/store/slot {slot:"hotbar.2",path:"Items[{Slot:2b}]"}
execute if score #graves.keep_hotbar mp.settings matches 0 run function m_graves:graves/store/slot {slot:"hotbar.3",path:"Items[{Slot:3b}]"}
execute if score #graves.keep_hotbar mp.settings matches 0 run function m_graves:graves/store/slot {slot:"hotbar.4",path:"Items[{Slot:4b}]"}
execute if score #graves.keep_hotbar mp.settings matches 0 run function m_graves:graves/store/slot {slot:"hotbar.5",path:"Items[{Slot:5b}]"}
execute if score #graves.keep_hotbar mp.settings matches 0 run function m_graves:graves/store/slot {slot:"hotbar.6",path:"Items[{Slot:6b}]"}
execute if score #graves.keep_hotbar mp.settings matches 0 run function m_graves:graves/store/slot {slot:"hotbar.7",path:"Items[{Slot:7b}]"}
execute if score #graves.keep_hotbar mp.settings matches 0 run function m_graves:graves/store/slot {slot:"hotbar.8",path:"Items[{Slot:8b}]"}
execute if score #graves.keep_hotbar mp.settings matches 0 run function m_graves:graves/store/slot {slot:"weapon.offhand",path:"Items[{Slot:weapon.offhand}]"}
execute if score #graves.keep_armor mp.settings matches 0 run function m_graves:graves/store/slot {slot:"armor.head",path:"Items[{Slot:armor.head}]"}
execute if score #graves.keep_armor mp.settings matches 0 run function m_graves:graves/store/slot {slot:"armor.chest",path:"Items[{Slot:armor.chest}]"}
execute if score #graves.keep_armor mp.settings matches 0 run function m_graves:graves/store/slot {slot:"armor.legs",path:"Items[{Slot:armor.legs}]"}
execute if score #graves.keep_armor mp.settings matches 0 run function m_graves:graves/store/slot {slot:"armor.feet",path:"Items[{Slot:armor.feet}]"}
function m_graves:graves/store/slot {slot:"inventory.0",path:"Items[{Slot:9b}]"}
function m_graves:graves/store/slot {slot:"inventory.1",path:"Items[{Slot:10b}]"}
function m_graves:graves/store/slot {slot:"inventory.2",path:"Items[{Slot:11b}]"}
function m_graves:graves/store/slot {slot:"inventory.3",path:"Items[{Slot:12b}]"}
function m_graves:graves/store/slot {slot:"inventory.4",path:"Items[{Slot:13b}]"}
function m_graves:graves/store/slot {slot:"inventory.5",path:"Items[{Slot:14b}]"}
function m_graves:graves/store/slot {slot:"inventory.6",path:"Items[{Slot:15b}]"}
function m_graves:graves/store/slot {slot:"inventory.7",path:"Items[{Slot:16b}]"}
function m_graves:graves/store/slot {slot:"inventory.8",path:"Items[{Slot:17b}]"}
function m_graves:graves/store/slot {slot:"inventory.9",path:"Items[{Slot:18b}]"}
function m_graves:graves/store/slot {slot:"inventory.10",path:"Items[{Slot:19b}]"}
function m_graves:graves/store/slot {slot:"inventory.11",path:"Items[{Slot:20b}]"}
function m_graves:graves/store/slot {slot:"inventory.12",path:"Items[{Slot:21b}]"}
function m_graves:graves/store/slot {slot:"inventory.13",path:"Items[{Slot:22b}]"}
function m_graves:graves/store/slot {slot:"inventory.14",path:"Items[{Slot:23b}]"}
function m_graves:graves/store/slot {slot:"inventory.15",path:"Items[{Slot:24b}]"}
function m_graves:graves/store/slot {slot:"inventory.16",path:"Items[{Slot:25b}]"}
function m_graves:graves/store/slot {slot:"inventory.17",path:"Items[{Slot:26b}]"}
function m_graves:graves/store/slot {slot:"inventory.18",path:"Items[{Slot:27b}]"}
function m_graves:graves/store/slot {slot:"inventory.19",path:"Items[{Slot:28b}]"}
function m_graves:graves/store/slot {slot:"inventory.20",path:"Items[{Slot:29b}]"}
function m_graves:graves/store/slot {slot:"inventory.21",path:"Items[{Slot:30b}]"}
function m_graves:graves/store/slot {slot:"inventory.22",path:"Items[{Slot:31b}]"}
function m_graves:graves/store/slot {slot:"inventory.23",path:"Items[{Slot:32b}]"}
function m_graves:graves/store/slot {slot:"inventory.24",path:"Items[{Slot:33b}]"}
function m_graves:graves/store/slot {slot:"inventory.25",path:"Items[{Slot:34b}]"}
function m_graves:graves/store/slot {slot:"inventory.26",path:"Items[{Slot:35b}]"}
