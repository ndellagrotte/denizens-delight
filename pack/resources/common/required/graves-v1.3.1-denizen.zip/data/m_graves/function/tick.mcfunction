## Called every tick
execute as @a[scores={mp.death=1..}] at @s if score #graves mp.settings matches 1 run function m_graves:graves/on_death
