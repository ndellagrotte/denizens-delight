## Navigates settings menus based on mp.settings score
scoreboard players enable @s mp.settings
function #mp_utils:settings_nav
execute if score @s mp.settings matches 1 run function mp_utils:settings/open with storage multipack:settings
execute if score @s mp.settings matches -1 run dialog clear @s
scoreboard players set @s mp.settings 0
