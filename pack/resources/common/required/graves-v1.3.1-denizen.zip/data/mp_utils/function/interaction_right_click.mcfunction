## Called by 'right_click_interaction' advancement
advancement revoke @s only mp_utils:right_click_interaction
tag @s add multipack.interactor
# Legacy
tag @e[distance=..10,type=interaction,tag=multipack.grave] add multipack.interaction

execute as @e[distance=..10,type=interaction,tag=multipack.interaction] at @s on target if entity @s[tag=multipack.interactor] \
        as @n[distance=..0.1,type=interaction,tag=multipack.grave] run function #mp_utils:on_interaction_right_click
tag @s remove multipack.interactor
